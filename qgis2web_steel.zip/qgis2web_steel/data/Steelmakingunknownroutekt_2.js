var json_Steelmakingunknownroutekt_2 = {
"type": "FeatureCollection",
"name": "Steelmakingunknownroutekt_2",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "Country": "Ghana", "Nominal cr": 800.0, "Main produ": "unknown", "lon": -0.023595, "lat": 5.70949 }, "geometry": { "type": "Point", "coordinates": [ -0.023595, 5.70949 ] } },
{ "type": "Feature", "properties": { "Country": "Kenya", "Nominal cr": 1000.0, "Main produ": "unknown", "lon": 37.991283, "lat": 0.461697 }, "geometry": { "type": "Point", "coordinates": [ 37.991283, 0.461697 ] } },
{ "type": "Feature", "properties": { "Country": "China", "Nominal cr": 6000.0, "Main produ": "unknown", "lon": 113.968635, "lat": 36.631491 }, "geometry": { "type": "Point", "coordinates": [ 113.968635, 36.631491 ] } },
{ "type": "Feature", "properties": { "Country": "China", "Nominal cr": 3375.0, "Main produ": "unknown", "lon": 116.422599, "lat": 34.013369 }, "geometry": { "type": "Point", "coordinates": [ 116.422599, 34.013369 ] } },
{ "type": "Feature", "properties": { "Country": "China", "Nominal cr": 1700.0, "Main produ": "unknown", "lon": 115.284652, "lat": 30.097108 }, "geometry": { "type": "Point", "coordinates": [ 115.284652, 30.097108 ] } },
{ "type": "Feature", "properties": { "Country": "China", "Nominal cr": 1700.0, "Main produ": "unknown", "lon": 102.312086, "lat": 25.023852 }, "geometry": { "type": "Point", "coordinates": [ 102.312086, 25.023852 ] } },
{ "type": "Feature", "properties": { "Country": "India", "Nominal cr": 5000.0, "Main produ": "unknown", "lon": 76.659122, "lat": 15.203176 }, "geometry": { "type": "Point", "coordinates": [ 76.659122, 15.203176 ] } },
{ "type": "Feature", "properties": { "Country": "North Korea", "Nominal cr": 760.0, "Main produ": "unknown", "lon": 125.414672, "lat": 38.729864 }, "geometry": { "type": "Point", "coordinates": [ 125.414672, 38.729864 ] } },
{ "type": "Feature", "properties": { "Country": "Pakistan", "Nominal cr": 500.0, "Main produ": "unknown", "lon": 72.019181, "lat": 34.124213 }, "geometry": { "type": "Point", "coordinates": [ 72.019181, 34.124213 ] } },
{ "type": "Feature", "properties": { "Country": "China", "Nominal cr": 1600.0, "Main produ": "ironmaking (other)", "lon": 111.134606, "lat": 23.402121 }, "geometry": { "type": "Point", "coordinates": [ 111.134606, 23.402121 ] } }
]
}
