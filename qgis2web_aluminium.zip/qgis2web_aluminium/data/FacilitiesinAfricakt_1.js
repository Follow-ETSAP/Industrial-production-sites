var json_FacilitiesinAfricakt_1 = {
"type": "FeatureCollection",
"name": "FacilitiesinAfricakt_1",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [
{ "type": "Feature", "properties": { "Country": "Cameroon", "DsgAttr02": "Aluminum", "DsgAttr03": "<null>", "Latitude": 3.819326, "Longitude": 10.12447, "DsgAttr07": 100.0 }, "geometry": { "type": "Point", "coordinates": [ 10.12447, 3.819326 ] } },
{ "type": "Feature", "properties": { "Country": "Egypt", "DsgAttr02": "Aluminum", "DsgAttr03": "Secondary", "Latitude": 29.905469, "Longitude": 30.899476, "DsgAttr07": 14.0 }, "geometry": { "type": "Point", "coordinates": [ 30.899476, 29.905469 ] } },
{ "type": "Feature", "properties": { "Country": "Egypt", "DsgAttr02": "Aluminum", "DsgAttr03": "Secondary", "Latitude": null, "Longitude": null, "DsgAttr07": null }, "geometry": null },
{ "type": "Feature", "properties": { "Country": "Egypt", "DsgAttr02": "Aluminum", "DsgAttr03": "Secondary", "Latitude": 30.156701, "Longitude": 31.303231, "DsgAttr07": 10.0 }, "geometry": { "type": "Point", "coordinates": [ 31.303231, 30.156701 ] } },
{ "type": "Feature", "properties": { "Country": "Egypt", "DsgAttr02": "Aluminum", "DsgAttr03": "Secondary", "Latitude": 30.856669, "Longitude": 32.319146, "DsgAttr07": 25.0 }, "geometry": { "type": "Point", "coordinates": [ 32.319146, 30.856669 ] } },
{ "type": "Feature", "properties": { "Country": "Egypt", "DsgAttr02": "Aluminum", "DsgAttr03": "Secondary", "Latitude": 29.873469, "Longitude": 31.328705, "DsgAttr07": 45.0 }, "geometry": { "type": "Point", "coordinates": [ 31.328705, 29.873469 ] } },
{ "type": "Feature", "properties": { "Country": "Egypt", "DsgAttr02": "Aluminum", "DsgAttr03": "Secondary", "Latitude": 31.198494, "Longitude": 29.941973, "DsgAttr07": 50.0 }, "geometry": { "type": "Point", "coordinates": [ 29.941973, 31.198494 ] } },
{ "type": "Feature", "properties": { "Country": "Egypt", "DsgAttr02": "Aluminum", "DsgAttr03": "Secondary", "Latitude": 29.865901, "Longitude": 31.329872, "DsgAttr07": 6.0 }, "geometry": { "type": "Point", "coordinates": [ 31.329872, 29.865901 ] } },
{ "type": "Feature", "properties": { "Country": "Egypt", "DsgAttr02": "Aluminum", "DsgAttr03": "Secondary", "Latitude": 29.888573, "Longitude": 31.309513, "DsgAttr07": 12.0 }, "geometry": { "type": "Point", "coordinates": [ 31.309513, 29.888573 ] } },
{ "type": "Feature", "properties": { "Country": "Egypt", "DsgAttr02": "Aluminum", "DsgAttr03": "Secondary", "Latitude": 30.584574, "Longitude": 32.210124, "DsgAttr07": 15.0 }, "geometry": { "type": "Point", "coordinates": [ 32.210124, 30.584574 ] } },
{ "type": "Feature", "properties": { "Country": "Egypt", "DsgAttr02": "Aluminum", "DsgAttr03": "Primary and Secondary", "Latitude": 25.988763, "Longitude": 32.331794, "DsgAttr07": 320.0 }, "geometry": { "type": "Point", "coordinates": [ 32.331794, 25.988763 ] } },
{ "type": "Feature", "properties": { "Country": "Ghana", "DsgAttr02": "Aluminum", "DsgAttr03": "<null>", "Latitude": 5.668303, "Longitude": 0.022344, "DsgAttr07": 200.0 }, "geometry": { "type": "Point", "coordinates": [ 0.022344, 5.668303 ] } },
{ "type": "Feature", "properties": { "Country": "Guinea", "DsgAttr02": "Alumina", "DsgAttr03": "<null>", "Latitude": 10.386001, "Longitude": -13.579689, "DsgAttr07": 650.0 }, "geometry": { "type": "Point", "coordinates": [ -13.579689, 10.386001 ] } },
{ "type": "Feature", "properties": { "Country": "Kenya", "DsgAttr02": "Aluminum", "DsgAttr03": "Secondary", "Latitude": -1.248554, "Longitude": 36.673684, "DsgAttr07": 1.0 }, "geometry": { "type": "Point", "coordinates": [ 36.673684, -1.248554 ] } },
{ "type": "Feature", "properties": { "Country": "Kenya", "DsgAttr02": "Aluminum", "DsgAttr03": "Secondary", "Latitude": -1.218188, "Longitude": 36.654363, "DsgAttr07": 1.2 }, "geometry": { "type": "Point", "coordinates": [ 36.654363, -1.218188 ] } },
{ "type": "Feature", "properties": { "Country": "Kenya", "DsgAttr02": "Aluminum", "DsgAttr03": "Secondary", "Latitude": -4.006381, "Longitude": 39.603881, "DsgAttr07": 1.0 }, "geometry": { "type": "Point", "coordinates": [ 39.603881, -4.006381 ] } },
{ "type": "Feature", "properties": { "Country": "Kenya", "DsgAttr02": "Aluminum", "DsgAttr03": "Secondary", "Latitude": -3.970952, "Longitude": 39.549887, "DsgAttr07": 15.0 }, "geometry": { "type": "Point", "coordinates": [ 39.549887, -3.970952 ] } },
{ "type": "Feature", "properties": { "Country": "Kenya", "DsgAttr02": "Aluminum", "DsgAttr03": "Secondary", "Latitude": -1.044363, "Longitude": 37.101837, "DsgAttr07": 4.0 }, "geometry": { "type": "Point", "coordinates": [ 37.101837, -1.044363 ] } },
{ "type": "Feature", "properties": { "Country": "Mozambique", "DsgAttr02": "Aluminum", "DsgAttr03": "Aluminum", "Latitude": -25.916155, "Longitude": 32.409465, "DsgAttr07": 561.0 }, "geometry": { "type": "Point", "coordinates": [ 32.409465, -25.916155 ] } },
{ "type": "Feature", "properties": { "Country": "South Africa", "DsgAttr02": "Aluminum", "DsgAttr03": "Aluminum", "Latitude": -28.765745, "Longitude": 32.028092, "DsgAttr07": 726.0 }, "geometry": { "type": "Point", "coordinates": [ 32.028092, -28.765745 ] } },
{ "type": "Feature", "properties": { "Country": "Tunisia", "DsgAttr02": "Aluminum", "DsgAttr03": "Aluminum fluoride", "Latitude": 37.259047, "Longitude": 9.850862, "DsgAttr07": 42.0 }, "geometry": { "type": "Point", "coordinates": [ 9.850862, 37.259047 ] } }
]
}
